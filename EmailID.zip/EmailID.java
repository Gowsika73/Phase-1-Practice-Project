package Practiceproject;
import java.util.ArrayList;
import java.util.Scanner;
public class EmailID {

	public static void main(String[] args) {
    ArrayList<String> email = new ArrayList<String>();
   
        email.add("xxx.yyy@gmail.com");
        email.add("hfhg.hfgdfygi@vbn.com");
        email.add("bstchinku@gmx.com");
        email.add("nve.ujrd@gmail.com");
        email.add("kmgekmnjnd@bvc.com");
         String searchEmail = null;
         System.out.println("Enter the email to search");
         
         Scanner sc = new Scanner(System.in); 
			System.out.println("Enter email Id : ");
          searchEmail = sc.nextLine(); 
		
             if(email.contains(searchEmail)){
          System.out.println("EmailID found");
      }
      else{
          System.out.println( "EmailID not found");
      }
      sc.close();
	}

}
