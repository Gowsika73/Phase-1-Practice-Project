package Practiceproject;
import java.io.*;
import java.util.Scanner;
public class Filehandling {
	void Filewrite(){
		String data="Filewriter method is created.";
		try{
			FileWriter fw=new FileWriter("E:\\File.txt");
			fw.write(data);
			fw.close();
			System.out.println("Sucessfully written to file");
		}
		catch(Exception e){
			System.out.println("Error");
		}
	}
void Fileread(){
	char [] data=new char[30];
	try{
		FileReader fr=new FileReader("E:\\File.txt");
		fr.read(data);
	    System.out.println("Data is received from a file.");
	    System.out.println(data);
	    fr.close();
	}
	catch(Exception e){
		System.out.println("Error");
	}
	}
void Append(){
	String data="This data is appended";
	try{
	FileWriter fw=new FileWriter("E:\\File.txt",true);
	fw.write(data);
	fw.close();
	System.out.println("Data is appended");
	}
	catch(Exception e){
		System.out.println("Error");
	}
	
}
	public static void main(String[] args) {
	    Filehandling f=new Filehandling();
	    f.Filewrite();
	    f.Fileread();
	    f.Append();
	    
	}

}
